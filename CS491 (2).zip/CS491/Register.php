<?php
    include "connection.php";

    

    //Hashes password for security
    function hashPassword($password) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        return $hashedPassword;
    }

    //Checks for valid njit email
    function checkValidEmail($email) {
      $pattern = "/^.+@njit\.edu/i";
      return preg_match($pattern , $email);
    }

    //Checks if the user already exists in the system
    function checkExistingUser($email) {
      $query = "SELECT email from tickets";
      $result = $con->query($query);
      while($row = $result->fetch_assoc()) {
        if ($email == $row['email']) {
            return TRUE;
        }
      }
      return FALSE;
    }

    $str_json = file_get_contents("php://input"); 
    $response = json_decode($str_json, true);
    var_dump($str_json);

    if(isset($response['first'])) $fname = $response['first'];
    if(isset($response['last'])) $lname = $response['last'];
    if(isset($response['email'])) $email = $response['email'];
    if(isset($response['password'])) $pass = $response['password'];

    if(isset($response['cardname'])) $name = $response['cardname'];
    if(isset($response['date'])) $date = $response['date'];
    if(isset($response['cvv'])) $cvv = $response['cvv'];
    if(isset($response['cardnumber'])) $cardNum = $response['cardnumber'];
    if(isset($response['address'])) $add = $response['address'];
    if(isset($response['zip'])) $zip = $response['zip'];
    
    $hashPass = hashPassword($pass);
    //$existingUser = checkExistingUser($email);
    $isEmailValid = checkValidEmail($email);
    echo $response;
    
    //$data = array('message' => "Test message");
    //$json_res = json_encode($data, true);
    
    if(!$isEmailValid) {
      $data = array('message' => "User does not have a valid njit email address");
      $json_res = json_encode($data, true);
      echo $json_res;
    }
    else if ($existingUser == TRUE) { 
      $data = array('message' => "User already exists in system");
      $json_res = json_encode($data, true);
      echo $json_res;
    }
    else {
      $query = "INSERT into tickets (Fname, Lname, email, pass) VALUES ($fname, $lname, $email, $hashPass)";
      $result = $con->query($query);
      $query2 = "INSERT into payment (Name, date, cvv, cardNumber, address, zip) VALUES ($name, $date, $cvv, $cardNum, $add, $zip)";
      $result = $con->query($query2);
      $data = array('message' => "registration successful");
      $json_res = json_encode($data, true);
      echo $json_res;
    }
    
    $con->close();
?>
