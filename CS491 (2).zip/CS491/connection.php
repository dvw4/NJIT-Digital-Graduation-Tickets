<?php
 $dbhost = "sql1.njit.edu";
 $dbuser = "dvw4";
 $dbpass = "Pearson@2022";
 $db = "dvw4";

  $con = mysqli_connect($dbhost, $dbuser, $dbpass, $db);
  
     if (mysqli_connect_errno())
     {
         echo "Failed to connect to MySQL: " . mysqli_connect_error();

         exit();
     }
?>