<?php
    include "connection.php";
    
    //Checks for valid njit email
    function checkValidEmail($email) {
      $pattern = "/^.+@njit\.edu/i";
      return preg_match($pattern , $email);
    }
    
    //Verfies if password matches hash stored in database
    function checkPassword($result, $email, $password)
    {
        while($row = $result->fetch_assoc())
        {
            if ($email == $row['email'] and password_verify($password, $row['pass']))
            {
                return True;
            }
        }
        return False;
    }

    $str_json = file_get_contents("php://input"); 
    $response = json_decode($str_json, true);

    if(isset($response['email'])) $email = $response['email'];
    if(isset($response['password'])) $pass = $response['password'];
    
    $isEmailValid = checkValidEmail($email);
    $query = "SELECT * FROM Login";
    $result = $con->query($query);

    $stat = checkPassword($result, $email, $pass);
    if (!$isEmailValid or !$stat) {
      $json_res = json_encode("Invalid email or password");
    }
    else {
      $json_res = json_encode($stat);
    }
    echo $json_res;
    $con->close();
?>
