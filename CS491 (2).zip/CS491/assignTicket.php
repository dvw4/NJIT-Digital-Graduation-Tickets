<?php
  include 'connection.php';
  
  
  #$str = '{"email":"j@njit.edu"}';
  $str = file_get_contents('php://input',true);  
  $json = json_decode($str,true);
  $email = $json['email'];
  
  $data = array('message'=> "assignement failed");
  $json_res = json_encode($data, true);;
  
  $query = "SELECT * FROM QRcodes";
  $result = mysqli_query($con, $query);
  while($row = $result->fetch_assoc()) {
        if (empty($row['email'])) {
            $code = $row['code'];
            $query2 = "UPDATE QRcodes SET email = '$email' WHERE code = '$code'";
            $result = mysqli_query($con, $query2);
            $data = array('message'=> "ticket assigned");
            $json_res = json_encode($data, true);
            break;
        }
    }
    echo $json_res;
?>