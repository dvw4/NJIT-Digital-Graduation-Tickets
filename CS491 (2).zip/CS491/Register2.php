<?php
  include 'connection.php';
  
  //Hashes password for security
    function hashPassword($password) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        return $hashedPassword;
    }

    //Checks for valid njit email
    function checkValidEmail($email) {
      $pattern = "/^.+@njit\.edu/i";
      return preg_match($pattern , $email);
    }

    //Checks if the user already exists in the system
    function checkExistingUser($email) {
      global $con;
      $query = "SELECT * from tickets";
      $result = mysqli_query($con, $query);
      while($row = $result->fetch_assoc()) {
        if (strcmp($email,  $row['email']) == 0) {
            return TRUE;
        }
      }
      return FALSE;
    }
    
    //Check matching password hashes
    function checkPassword($result, $email, $password)
    {
        while($row = $result->fetch_assoc())
        {
            if (strcmp($email,  $row['email']) == 0 and password_verify($password, $row['pass']))
            {
                return True;
            }
        }
        return False;
    }
    
    function graduatingStudent($email){
      global $con;
      $query = "SELECT * from graduatingstu";
      $result = mysqli_query($con, $query);
      while($row = $result->fetch_assoc()) {
        if (strcmp($email,  $row['email']) == 0) {
            return TRUE;
        }
      }
      return FALSE;
    }
  #$str = '{"requestType":"login","email":"j@njit.edu","password":"jklm"}';
  #$str = '{"requestType":"register","email":"j@njit.edu","password":"jklm","first":"jklm","last":"jklm","cardname":"jklm","date":"45621","cvv":"321","cardnumber":"1111111111111111","address":"jklm","zip":"98765"}';
  $str = file_get_contents('php://input',true);
  $json = json_decode($str,true);
  
  
  $requestType = $json['requestType'];
  switch($requestType){
        case 'register':
              global $con;
              $email = $json['email'];
              $password = $json['password'];
              $fname = $json['first'];
              $lname = $json['last'];
              
              $name = $json['cardname'];
              $date = $json['date'];
              $cvv = $json['cvv'];
              $cardNum = $json['cardnumber'];
              $add = $json['address'];
              $zip = $json['zip'];
              
              
              
              if(strlen($cardNum) != 16) {
                $data = array('message' => "User has inputted incorrect card number digits");
                $json_res = json_encode($data, true);
                echo $json_res;
                break;
              }
              
              $hashPass = hashPassword($password);
              
              /*
              $isGraduating = graduatingStudent($email);
              if(!$isGraduating) {
                $data = array('message' => "User is not listed to be graduating");
                $json_res = json_encode($data, true);
                echo $json_res;
                break;
              }
              */
              $isEmailValid = checkValidEmail($email);
              if(!$isEmailValid) {
                $data = array('message' => "User does not have a valid njit email address");
                $json_res = json_encode($data, true);
                echo $json_res;
                break;
              }
              
              $existingUser = checkExistingUser($email);
              if ($existingUser == TRUE) { 
                $data = array('message' => "User already exists in system");
                $json_res = json_encode($data, true);
                echo $json_res;
                break;
              }
              
              $query = "INSERT INTO tickets(email,pass, Fname, Lname) VALUES('$email','$hashPass', '$fname', '$lname')";
              $result = mysqli_query($con, $query);
              $query2 = "INSERT INTO payment(Name, date, cvv, cardNumber, address, zip) VALUES('$name', '$date', '$cvv', '$cardNum', '$add', '$zip')";
              $result = mysqli_query($con, $query2);
              
              $ticketData = array('email' => $email);
              
              $jsn = json_encode($ticketData,true);
              $url = "https://afsaccess4.njit.edu/~jda52/CS491/qrcode.php";

              $curl = curl_init();
              curl_setopt($curl, CURLOPT_URL,$url);
              curl_setopt($curl, CURLOPT_HTTPHEADER, array('Accept: application/json','Content-Type: application/json'));
              curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
              curl_setopt($curl, CURLOPT_POSTFIELDS, $jsn);
              
              $ticketStatus = True;
              for($x = 0; $x < 4; $x++) {
              
                $resp = curl_exec($curl);
                $jsnDec = json_decode($resp, true);
                
                if(strcmp($jsnDec['message'],  "ticket added") != 0) {
                  $ticketStatus = False;
                  break;
                }
              }
              curl_close($curl);
              
              if($ticketStatus == False) {
                $data = array('message'=> 'Ticket error');
                $json_res = json_encode($data, true);
                echo $json_res;
                break;
              }
              
              $data = array('message'=> 'Verified');
              $json_res = json_encode($data, true);
              echo $json_res;
              break;
              
        case 'login':
          global $con;
          $email = $json['email'];
          $password = $json['password'];
          
          $isEmailValid = checkValidEmail($email);
          $query = "SELECT * FROM tickets";
          $result = $con->query($query);
          $stat = checkPassword($result, $email, $password);
          if (!$isEmailValid or !$stat) {
            $json_res = json_encode(array('message' => "fail"));
            echo $json_res;
          }
          else {
             $query2 = "SELECT code FROM QRcodes WHERE email = '$email'";
             $result = $con->query($query2);
             $codeArray = array();
             
             while($row = $result->fetch_assoc()) {
                array_push($codeArray, $row['code']);
             }
          
             $json_res = json_encode(array('message' => "success", 'email' => $email, 'codes' => $codeArray));
             echo $json_res;
          }
          break;
        }
?>