<?php
  
  $str = file_get_contents('php://input',true);
  $json = json_decode($str,true);
              
  $jsn = json_encode($json,true);
  $url = "https://afsaccess4.njit.edu/~jda52/CS491/qrcode.php";

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL,$url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Accept: application/json','Content-Type: application/json'));
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $jsn);
              
  $resp = curl_exec($curl);
  $jsnDec = json_decode($resp, true);
  
  $data = array('message'=> "ticket added");
  $json_res = json_encode($data, true);
  
  echo $json_res;
?>