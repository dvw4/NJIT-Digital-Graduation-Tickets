<?php
  include "/afs/cad.njit.edu/u/j/d/jda52/public_html/CS491/connection.php";
  include "/afs/cad.njit.edu/u/j/d/jda52/public_html/CS491/phpqrcode/qrlib.php";
  
  //$email = "j@njit.edu";
  
  //$query2 = "SELECT code FROM QRcodes WHERE email = '$email'";
  //$result = $con->query($query2);
  //$codeArray = array();
             
  //while($row = $result->fetch_assoc()) {
  //        array_push($codeArray, $row['code']);
  //}
  //echo "<table border=1>";
  //echo "current user: ". get_current_user();
  //echo "script was executed under: " .exec("whoami");
  
  
  
  //echo scandir("~/public_html/CS491/Frontend");
  $file = "test.txt";
  $myfile = fopen($file, 'x');
  
  //$path = "~/public_html/CS491/Frontend/images/";
  //$file = path.uniqid().".png";
  //QRcode::png("test", $file);
  
  //foreach($codeArray as $code){
    //echo "<tr>";
    //echo "<td>$code</td>";
    //echo "</tr>";
  //}
  //echo "</table>";
?>