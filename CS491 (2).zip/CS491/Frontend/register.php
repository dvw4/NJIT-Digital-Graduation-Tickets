<?php 
    $requestType = "register";
    $firstname = $_POST['first'];
    $lastname = $_POST['last'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cardname = $_POST['cardname'];
    $date = $_POST['date'];
    $cvv = $_POST['cvv'];
    $cardnumber = $_POST['cardnumber'];
    $address = $_POST['address'];
    $zip = $_POST['zip'];


    $data = array('requestType' => $requestType, 'email' => $email, 'password' => $password, 'first' => $firstname, 'last' => $lastname, 'cardname' => $cardname, 'date' => $date, 'cvv' => $cvv, 'cardnumber' => $cardnumber, 'address' => $address, 'zip' => $zip);


    $jsn = json_encode($data,true);
    $url = "https://afsaccess4.njit.edu/~jda52/CS491/Register2.php";

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL,$url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Accept: application/json','Content-Type: application/json'));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $jsn);


    $resp = curl_exec($curl);
    $json = json_decode($resp, true);
    echo $json['message'];
    echo $json['query'];
    /*
    $jsn = json_decode($resp,true);
    $msg = $jsn['message'];
    echo $msg;
    */
    curl_close($curl);

?>