<?php
  $file = "test.txt";
  $myfile = fopen($file, 'w');
?>