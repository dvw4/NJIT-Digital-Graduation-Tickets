<?php
  include 'phpqrcode/qrlib.php';
  include 'connection.php';
  
  
  function checkQRCode($code) {
    global $con;
    
    $query = "SELECT code from QRcodes";
    $result = mysqli_query($con, $query);
    while($row = $result->fetch_assoc()) {
        if (strcmp($code,  $row['code']) == 0) {
            return TRUE;
        }
        return FALSE;
    }
  }
  
  function randomString(){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    
    for ($i = 0; $i < 300; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
    return $randomString;
  }
  
  global $con;
  #$str = '{"email":"j@njit.edu"}';
  
  $str = file_get_contents('php://input',true);  
  $json = json_decode($str,true);
  $email = $json['email'];
  $code = randomString();
  
  while(checkQRCode($code)) {
    $code = randomString();
  }
    
  $query = "INSERT INTO QRcodes(email,code) VALUES('$email','$code')";
  $result = mysqli_query($con, $query);
  
  $data = array('message'=> "ticket added");
  $json_res = json_encode($data, true);
  echo $json_res;
?>